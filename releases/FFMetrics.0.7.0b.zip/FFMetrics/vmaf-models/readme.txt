VMAF Models from Netflix project: https://github.com/Netflix/vmaf
